#!/usr/bin/python

import os
os.system('/usr/bin/sudo /home/osmc/poweroff.py r')
