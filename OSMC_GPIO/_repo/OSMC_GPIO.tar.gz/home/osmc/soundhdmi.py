#!/usr/bin/python
import os

os.system('/usr/bin/xbmc-send -a "Notification(AUDIO OUTPUT,Switched to HDMI)"')
