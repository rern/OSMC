<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>OSMC - GPIO</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no" />
	<link rel="stylesheet" href="./assets/css/runeui.css">
	<link rel="stylesheet" href="./assets/css/gpiosettings.css">
	<link rel="shortcut icon" type="image/png" href="https://blog-cdn.osmc.tv/assets/img/favicon/favicon.ico?v=b1c7d0993b">
</head>

<?php
$file = '/home/osmc/gpio.json';
$fileopen = fopen($file, 'r');
$gpio = fread($fileopen, filesize($file));
fclose($fileopen);
$gpio = json_decode($gpio, true);

$enable = $gpio['enable']['enable'];

$pin1 = $gpio['pin']['pin1'];
$pin2 = $gpio['pin']['pin2'];
$pin3 = $gpio['pin']['pin3'];
$pin4 = $gpio['pin']['pin4'];
$pincount = ($pin1 == 0?0:1) + ($pin2 == 0?0:1) + ($pin3 == 0?0:1) + ($pin4 == 0?0:1);

$name1 = $gpio['name']['name1'];
$name2 = $gpio['name']['name2'];
$name3 = $gpio['name']['name3'];
$name4 = $gpio['name']['name4'];

$on1 = $gpio['on']['on1'];
$ond1 = $gpio['on']['ond1'];
$on2 = $gpio['on']['on2'];
$ond2 = $gpio['on']['ond2'];
$on3 = $gpio['on']['on3'];
$ond3 = $gpio['on']['ond3'];
$on4 = $gpio['on']['on4'];

$off1 = $gpio['off']['off1'];
$offd1 = $gpio['off']['offd1'];
$off2 = $gpio['off']['off2'];
$offd2 = $gpio['off']['offd2'];
$off3 = $gpio['off']['off3'];
$offd3 = $gpio['off']['offd3'];
$off4 = $gpio['off']['off4'];

$timer = $gpio['timer']['timer'];

function optpin($n) {
	$pinarray = array(3,5,7,8,10,11,12,13,15,16,18,19,21,22,23,24,26,29,31,32,33,35,36,37,38,40);
	$option = '';
	foreach ($pinarray as $pin) {
		$selected = ($pin == $n) ? ' selected' : '';
		$option.= '<option value='.$pin.$selected.'>'.$pin.'</option>';
	}
	echo $option;
}
$parray = array(
	$pin1=>$name1,
	$pin2=>$name2,
	$pin3=>$name3,
	$pin4=>$name4
);
function optname($n) {
	global $parray;
	$option = '<option value="0">none</option>';
	foreach ($parray as $pin=>$name) {
		$selected = ($pin == $n) ? ' selected' : '';
		$option.= '<option value='.$pin.$selected.'>'.$name.' - '.$pin.'</option>';
	}
	echo $option;
}
function opttime($n) {
	$option = '<option value="0">none</option>';
	foreach ( range(1, 10) as $num) {
		$selected = ($num == $n) ? ' selected' : '';
		$option.= '<option value='.$num.$selected.'>'.$num.'</option>';
	}
	echo $option;
}
?>

<body>

<div class="container">
<h1>GPIO</h1>
<legend>Settings</legend>
<form class="form-horizontal">

<p>
	Controlling 'GPIO' P1 pins connected relay module for power on /off equipments in sequence.<br>
	Using <a id="gpioimgtxt" style="cursor: pointer">RPi pin numbering.</a>
</p>
<img src="assets/img/RPi3_GPIOs.png" style="display: none; margin-bottom: 10px;">
<div id="divgpio" class="<?php if($enable == 1) echo 'boxed-group'?>" >
	<div class="form-group">
		<label for="gpio" class="col-sm-2 control-label">Enable</label>
		<div class="col-sm-10">
			<label class="switch-light well" onclick="">
				<input id="gpio-enable" type="checkbox" <?=$enable == 1 ? 'value="1" checked="checked"' : 'value="0"';?>>
				<span><span>OFF</span><span>ON</span></span><a class="btn btn-primary"></a>
			</label>
		</div>
	</div>
	<div class="form-group" <?=$enable == 0 ? 'style="display:none"' : ''?> id="gpio-group">
		<label class="col-sm-2 control-label"></label>
		<div class="col-sm-10" id="gpio">
			<form></form> <!-- dummy for bypass 1st form not serialize -->
			<form id="gpioform">
				<div class="gpio-float-l">
						<div class="col-sm-10" id="gpio-num">
							<a class="gpio-text"><i class="fa fa-ellipsis-v fa-lg blue"></i> &nbsp; Pin</a>
							<select id="pin1" name="pin1" class="selectpicker pin">
								<?php optpin($pin1)?>
							</select>
							<select id="pin2" name="pin2" class="selectpicker pin">
								<?php optpin($pin2)?>
							</select>
							<select id="pin3" name="pin3" class="selectpicker pin">
								<?php optpin($pin3)?>
							</select>
							<select id="pin4" name="pin4" class="selectpicker pin">
								<?php optpin($pin4)?>
							</select>
							<a class="gpio-text"><i class="fa fa-clock-o fa-lg yellow"></i> &nbsp; Idle</a>
							<select id="timer" name="timer" class="selectpicker timer">
								<?php opttime($timer)?>
							</select>
						</div>
						<div class="col-sm-10" id="gpio-name">
							<a class="gpio-text"><i class="fa fa-tag fa-lg blue"></i> &nbsp; Name</a>
							<input id="name1" name="name1" type="text" class="form-control osk-trigger input-lg name" value="<?=$name1?>">
							<input id="name2" name="name2" type="text" class="form-control osk-trigger input-lg name" value="<?=$name2?>">
							<input id="name3" name="name3" type="text" class="form-control osk-trigger input-lg name" value="<?=$name3?>">
							<input id="name4" name="name4" type="text" class="form-control osk-trigger input-lg name" value="<?=$name4?>">
							<br>
							<span class="timer">&nbsp;min. to &nbsp;<i class="fa fa-power-off red"></i> &nbsp;Off</span>
						</div>
				</div>
				<div class="gpio-float-r">
						<div class="col-sm-10">
							<a class="gpio-text"><i class="fa fa-power-off fa-lg green"></i> &nbsp; On Sequence</a>
							<select id="on1" name="on1" class="selectpicker on">
								<?php optname($on1)?>
							</select>
							<select id="ond1" name="ond1" class="selectpicker ond delay">
								<?php opttime($ond1)?>
							</select> &nbsp; sec.
							<select id="on2" name="on2" class="selectpicker on">
								<?php optname($on2)?>
							</select>
							<select id="ond2" name="ond2" class="selectpicker ond delay">
								<?php opttime($ond2)?>
							</select> &nbsp; sec.
							<select id="on3" name="on3" class="selectpicker on">
								<?php optname($on3)?>
							</select>
							<select id="ond3" name="ond3" class="selectpicker ond delay">
								<?php opttime($ond3)?>
							</select> &nbsp; sec.
							<select id="on4" name="on4" class="selectpicker on">
								<?php optname($on4)?>
							</select>
						</div>
					<div class="col-sm-10" style="width: 20px;">
					</div>
						<div class="col-sm-10">
							<a class="gpio-text"><i class="fa fa-power-off fa-lg red"></i> &nbsp; Off Sequence</a>
							<select id="off1" name="off1" class="selectpicker off">
								<?php optname($off1)?>
							</select>
							<select id="offd1" name="offd1" class="selectpicker offd delay">
								<?php opttime($offd1)?>
							</select> &nbsp; sec.
							<select id="off2" name="off2" class="selectpicker off">
								<?php optname($off2)?>
							</select>
							<select id="offd2" name="offd2" class="selectpicker offd delay">
								<?php opttime($offd2)?>
							</select> &nbsp; sec.
							<select id="off3" name="off3" class="selectpicker off">
								<?php optname($off3)?>
							</select>
							<select id="offd3" name="offd3" class="selectpicker offd delay">
								<?php opttime($offd3)?>
							</select> &nbsp; sec.
							<select id="off4" name="off4" class="selectpicker off">
								<?php optname($off4)?>
							</select>
							<a id="gpiosave" class="btn btn-primary">Apply</a>
						</div>
				</div>
			</form>
			<div class="clear"></div>
		</div>
	</div>
</div>

</form>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="assets/js/vendor/bootstrap.min.js"></script>
<script src="assets/js/vendor/bootstrap-select-1.12.1.min.js"></script>
<script src="assets/js/gpiosettings.js"></script>

</body>
</html>
